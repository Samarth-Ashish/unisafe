import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:unisafe/features/student/report_widgets.dart';
import 'package:provider/provider.dart';
import 'package:unisafe/core/auth/auth_session.dart';
import 'package:unisafe/core/auth/user_info_extensions.dart';

class ResolvedReportsPage extends StatefulWidget {
  const ResolvedReportsPage({super.key,});

  @override
  State<ResolvedReportsPage> createState() => _ResolvedReportsPageState();
}

class _ResolvedReportsPageState extends State<ResolvedReportsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(centerTitle: true, backgroundColor: Colors.deepOrange.withValues(alpha: 0.7), title: const Text('Resolved Reports')),
      body: _buildReportsStream(),
    );
  }

  Widget _buildReportsStream() {
  final userEmail = context.watch<AuthSession>().user.emailOrEmpty;
  return StreamBuilder<QuerySnapshot>(
    stream: FirebaseFirestore.instance
        .collection('reports')
        .where('reportedFromEmail', isEqualTo: userEmail)
        .where('decisionPending', isEqualTo: false)
          .orderBy('submittedAt', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }
        if (snapshot.hasData && snapshot.data!.docs.isNotEmpty) {
          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              var data = snapshot.data!.docs[index].data() as Map<String, dynamic>;
              return buildReportCard(context, data);
            },
          );
        }
        return const Center(child: Text('No resolved reports found'));
      },
    );
  }
}
